<!DOCTYPE html>
<html lang="en-gb" dir="ltr">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="generator" content="Joomla! - Open Source Content Management">
	<title>Home</title>
	<link href="/elito/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0">
	<link href="/elito/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0">
	<link href="/elito/media/system/images/joomla-favicon.svg" rel="icon" type="image/svg+xml">
	<link href="/elito/media/system/images/favicon.ico" rel="alternate icon" type="image/vnd.microsoft.icon">
	<link href="/elito/media/system/images/joomla-favicon-pinned.svg" rel="mask-icon" color="#000">

	<link href="/elito/media/vendor/joomla-custom-elements/css/joomla-alert.min.css?0.2.0" rel="stylesheet" />
	<link href="/elito/plugins/system/jce/css/content.css?badb4208be409b1335b815dde676300e" rel="stylesheet" />

	<script type="application/json" class="joomla-script-options new">{"joomla.jtext":{"ERROR":"Error","MESSAGE":"Message","NOTICE":"Notice","WARNING":"Warning","JCLOSE":"Close","JOK":"OK","JOPEN":"Open"},"system.paths":{"root":"\/elito","rootFull":"https:\/\/demo-joomla.chipblue.net\/elito\/","base":"\/elito","baseFull":"https:\/\/demo-joomla.chipblue.net\/elito\/"},"csrf.token":"c98a05594b163a2bfc3d77250bc717b7"}</script>
	<script src="/elito/media/system/js/core.min.js?bea7b244e267b04087cedcf531f6fe827a8e101f"></script>
	<script src="/elito/media/system/js/messages-es5.min.js?70b6651d6deab46dc8a25f03338f66f540cc62e2" nomodule defer></script>
	<script src="/elito/media/system/js/messages.min.js?7425e8d1cb9e4f061d5e30271d6d99b085344117" type="module"></script>
	<script src="https://code.jquery.com/jquery-latest.pack.js"></script>
 
	<link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/themify-icons.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/flaticon.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/magnific-popup.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/animate.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/owl.carousel.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/owl.theme.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/slick.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/slick-theme.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/swiper.min.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/nice-select.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/owl.transitions.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/sass/style.css" rel="stylesheet">
    <link href="https://demo-joomla.chipblue.net/elito/templates/elito/assets/css/custom.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- LESS stylesheet for managing color presets 
    <link rel="stylesheet/less" type="text/css" 
        href="https://demo-joomla.chipblue.net/elito/templates/elito/less/color.php?color_left=&color_right=">
	-->
    <!-- LESS JS engine   
    <script src="https://demo-joomla.chipblue.net/elito/templates/elito/less/less-1.5.0.min.js"></script>-->
</head>

<body   
	class="site com_content view-featured no-layout no-task itemid-101" > 
<!-- start page-wrapper -->
<div class="page-wrapper">	
		<!-- start preloader -->
	<div class="preloader">
		<div class="vertical-centered-box">
			<div class="content">
				<div class="loader-circle"></div>
				<div class="loader-line-mask">
					<div class="loader-line"></div>
				</div>
				<img src="https://demo-joomla.chipblue.net/elito/images/preloader.png"  >
			</div>
		</div>
	</div>
	<!-- end preloader -->
			<!-- Start header -->
	<header id="header" class="wpo-header-style-1">
		<div class="wpo-site-header">
			<nav class="navigation navbar navbar-expand-lg navbar-light">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
							<div class="mobail-menu">
								<button type="button" class="navbar-toggler open-btn">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar first-angle"></span>
									<span class="icon-bar middle-angle"></span>
									<span class="icon-bar last-angle"></span>
								</button>
							</div>
						</div>
						<div class="col-lg-2 col-md-6 col-6">
							<div class="navbar-header">
								<a class="navbar-brand site-logo" href="https://demo-joomla.chipblue.net/elito/"><img
									 src="/elito/images/logo.png" alt="">Elito.</a>
							</div>
						</div>
						<div class="col-lg-8 col-md-1 col-1">
							<div id="navbar" class="collapse navbar-collapse navigation-holder">
								<button class="menu-close"><i class="ti-close"></i></button>
								<ul class="nav navbar-nav mb-2 mb-lg-0  ">
<li class="  metismenu-item item-101 level-1 default current active deeper  parent menu-item-has-children"><a href="/elito/index.php" aria-current="page">Home</a><ul class="sub-menu"><li class="  metismenu-item item-126 level-2"><a href="/elito/index.php/home/home-2" >Home 2</a></li></ul></li><li class="  metismenu-item item-121 level-1"><a href="/elito/index.php/about" >About</a></li><li class="  metismenu-item item-122 level-1"><a href="/elito/index.php/services" >Services</a></li><li class="  metismenu-item item-123 level-1"><a href="/elito/index.php/portfolio" >Portfolio</a></li><li class="  metismenu-item item-124 level-1"><a href="/elito/index.php/blog" >Blog</a></li><li class="  metismenu-item item-125 level-1"><a href="/elito/index.php/contact" >Contact</a></li></ul> 

							</div><!-- end of nav-collapse -->
						</div>
						<div class="col-lg-2 col-md-2 col-2">
							<div class="header-right">
								
<div id="mod-custom136" class="mod-custom custom">
    <div class="header-btn"><a href="/elito/images/cv.jpg" class="theme-btn" title="ImageName" download="My Cv"> <img src="/elito/images/cv.jpg" alt="ImageName" class="hide-img" /> Resume </a></div></div>

							</div>
						</div>
					</div>
				</div><!-- end of container -->
			</nav>
		</div>
	</header>
	<!-- end of header -->
		 
	<div class="main-feature no-card ">
		
<div id="mod-custom109" class="mod-custom custom">
    <!-- start of hero -->
<section id="div" class="static-hero">
<div class="hero-container">
<div class="hero-inner">
<div class="container">
<div class="row align-items-center">
<div class="col-xl-6 col-lg-6 col-12">
<div class="wpo-static-hero-inner">
<div class="slide-title" data-swiper-parallax="300">
<h2><span>Hello,</span> I am Ronald.</h2>
</div>
<div class="slide-sub-title" data-swiper-parallax="300">
<h5>UI/UX Designer</h5>
</div>
<div class="slide-text" data-swiper-parallax="400">
<p>Must explain to how all this mistaken idea denouncing pleasure pain the system and expound the actua.</p>
</div>
<div class="clearfix">&nbsp;</div>
<div class="slide-btn"><a href="#" class="theme-btn">Hire Me</a></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="static-hero-right">
<div class="static-hero-img">
<div class="static-hero-img-inner"><img src="/elito/images/slider/1.jpg" alt="" />
<div class="icon-1 floating-item"><img src="/elito/images/icon/photoshop.svg" alt="" /></div>
<div class="icon-2 floating-item"><img src="/elito/images/icon/illustrator.svg" alt="" /></div>
<div class="icon-3 floating-item"><img src="/elito/images/icon/diamond.svg" alt="" /></div>
<div class="project floating-item">
<div class="icon"><i class="fi flaticon-verified"></i></div>
<div class="p-text">
<h3><span class="odometer" data-count="1500">00</span>+</h3>
<p>Complete Project</p>
</div>
</div>
</div>
</div>
</div>
<div class="shape-1">&nbsp;</div>
<div class="shape-2">&nbsp;</div>
<div class="shape-3">&nbsp;</div>
<div class="line-shape-1"><img src="/elito/images/slider/line-1.png" alt="" /></div>
<div class="line-shape-2"><img src="/elito/images/slider/line-2.png" alt="" /></div>
</section>
<!-- end of hero slider --></div>
</div>
  
		  
	 
	 
	 
		<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom110" class="mod-custom custom">
    <!-- start of wpo-about-area -->
<div class="wpo-about-area section-padding">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-5 col-md-12 col-sm-12">
<div class="wpo-about-exprience-wrap">
<div class="wpo-about-exprience">
<h2>08</h2>
<span>Years of Experience</span></div>
<div class="client">
<h3><span class="odometer" data-count="100">00</span>%</h3>
<p>Clients Satisfections</p>
</div>
</div>
</div>
<div class="col-lg-6 offset-lg-1 col-md-12 col-sm-12">
<div class="wpo-about-content">
<div class="wpo-about-title">
<h2>My Advantage</h2>
<p>Must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account the system and expound the actual and praising pain was born.</p>
</div>
<div class="wpo-about-funfact">
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="98">00</span>%</h3>
<p>Figma</p>
</div>
</div>
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="92">00</span>%</h3>
<p>Sketch</p>
</div>
</div>
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="88">00</span>%</h3>
<p>Photoshop</p>
</div>
</div>
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="72">00</span>%</h3>
<p>Illustrator</p>
</div>
</div>
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="43">00</span>%</h3>
<p>WordPress</p>
</div>
</div>
<div class="grid">
<div class="grid-inner">
<h3><span class="odometer" data-count="37">00</span>%</h3>
<p>ReactJS</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ab-shape">&nbsp;</div>
<div class="ab-shape-s2">&nbsp;</div>
<div class="line-shape-1"><img src="/elito/images/about/shape1.png" alt="" /></div>
<div class="line-shape-2"><img src="/elito/images/about/shape2.png" alt="" /></div>
</div>
<!-- end of wpo-about-area --></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom111" class="mod-custom custom">
    <!-- start of wpo-service-area -->
<div class="wpo-service-area section-padding">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-6 col-12">
<div class="wpo-section-title">
<h2>Popular Services</h2>
<p>Must explain to you how all this mistaken idea of denouncing pleasure born and give you a complete account the system</p>
</div>
</div>
</div>
<div class="wpo-service-wrap">
<ul id="myTab" class="nav nav-tabs" role="tablist">
<li class="nav-item" role="presentation"><a href="#Development" id="Development-tab" class="nav-link" data-bs-toggle="tab" role="tab" aria-controls="Development" aria-selected="true">Development</a></li>
<li class="nav-item" role="presentation"><a href="#Design" id="Design-tab" class="nav-link active" data-bs-toggle="tab" role="tab" aria-controls="Design" aria-selected="false">Design</a></li>
<li class="nav-item" role="presentation"><a href="#Marketing" id="Marketing-tab" class="nav-link" data-bs-toggle="tab" role="tab" aria-controls="Marketing" aria-selected="false">Marketing</a></li>
</ul>
<div class="tab-content">
<div id="Development" class="tab-pane" role="tabpanel">
<div class="row align-items-center">
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-coding"></i></div>
<h2>Web Development</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-app-development"></i></div>
<h2>App Development</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-smartphone"></i></div>
<h2>Softwere Development</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
</div>
</div>
<div id="Design" class="tab-pane active" role="tabpanel">
<div class="row align-items-center">
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-vector"></i></div>
<h2>Graphic Design</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-palette"></i></div>
<h2>Brand Identity</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-add"></i></div>
<h2>UI/UX Design</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
</div>
</div>
<div id="Marketing" class="tab-pane" role="tabpanel">
<div class="row align-items-center">
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-social-media"></i></div>
<h2>Social Media Marketing</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-promotion"></i></div>
<h2>Digital Marketing</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
<div class="col-lg-4 col-md-6 col-12">
<div class="wpo-service-item">
<div class="icon"><i class="fi flaticon-email-marketing"></i></div>
<h2>Email Marketing</h2>
<p>Explain to you how all this mistaken idea of denouncing pleasure born and give you complete account the system.</p>
<a href="/elito/service-single.html">Learn More</a></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ab-shape">&nbsp;</div>
</div>
<!-- end of wpo-service-area --></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom112" class="mod-custom custom">
    <!-- start of wpo-work-area -->
<div class="wpo-work-area section-padding">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-6 col-12">
<div class="wpo-section-title">
<h2>My Work Experience</h2>
<p>Must explain to you how all this mistaken idea of denouncing pleasure born and give you a complete account the system</p>
</div>
</div>
</div>
<div class="wpo-work-wrap">
<div class="wpo-work-item">
<ul>
<li class="date">2015 - 2016</li>
<li class="logo"><img src="/elito/images/work/1.png" alt="" /></li>
<li class="position">Junior Visual Designer <span>Trapeza Group, USA.</span></li>
<li class="link"><a href="#">Go to website</a></li>
</ul>
</div>
<div class="wpo-work-item">
<ul>
<li class="date">2017 - 2018</li>
<li class="logo"><img src="/elito/images/work/2.png" alt="" /></li>
<li class="position">UI/UX Designer <span>Gallerie Ontario, Canada <span>(Remote)</span></span></li>
<li class="link"><a href="#">Go to website</a></li>
</ul>
</div>
<div class="wpo-work-item">
<ul>
<li class="date">2019 - 2020</li>
<li class="logo"><img src="/elito/images/work/3.png" alt="" /></li>
<li class="position">Seinor UI/UX Desinger <span>Morson Hybrid, Canada</span></li>
<li class="link"><a href="#">Go to website</a></li>
</ul>
</div>
<div class="wpo-work-item">
<ul>
<li class="date">2019 - <span>Present</span></li>
<li class="logo"><img src="/elito/images/work/4.png" alt="" /></li>
<li class="position">Product Designer <span>Myant Inc. Etobicoke, ON <span>(Remote)</span></span></li>
<li class="link"><a href="#">Go to website</a></li>
</ul>
</div>
</div>
</div>
<div class="shape-wk">&nbsp;</div>
</div>
<!-- end of wpo-work-area --></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom115" class="mod-custom custom">
    <!-- start of wpo-project-area -->
<div class="wpo-project-area section-padding">
<div class="container">
<div class="wpo-section-title-s2">
<div class="row align-items-center">
<div class="col-lg-4 col-12">
<div class="title">
<h2>Recent Work.</h2>
<p>Must explain to you how all this mistaken idea pleasure born and give you a complete account.</p>
</div>
</div>
<div class="col-lg-6 offset-lg-2">
<div class="sec-title-icon"><i class="fi flaticon-self-growth"></i></div>
</div>
</div>
</div>
<div class="wpo-project-wrap wpo-project-slide owl-carousel">
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-1.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Architecture / Business</span></div>
</div>
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-2.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Web Design</span></div>
</div>
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-3.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Website / Creative</span></div>
</div>
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-1.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Architecture / Business</span></div>
</div>
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-2.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Web Design</span></div>
</div>
<div class="wpo-project-item">
<div class="wpo-project-img"><img src="/elito/images/project/img-3.jpg" alt="" /></div>
<div class="wpo-project-text">
<h2><a href="#">Title</a></h2>
<span>Website / Creative</span></div>
</div>
</div>
</div>
<div class="shape-p">&nbsp;</div>
<div class="line-shape-1"><img src="/elito/images/project/line-1.png" alt="" /></div>
<div class="line-shape-2"><img src="/elito/images/project/line-2.png" alt="" /></div>
</div>
<!-- end of wpo-project-area --></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom116" class="mod-custom custom">
    <!--Start wpo-testimonial-section-->
<section class="wpo-testimonial-section section-padding">
<div class="container">
<div class="wpo-testimonial-wrap">
<div class="row align-items-center">
<div class="col-lg-6 col-12">
<div class="testimonial-left">
<div class="testimonial-left-inner">
<div class="slider-for">
<div class="testimonial-img"><img src="/elito/images/testimonial/img-1.jpg" alt="" /></div>
<div class="testimonial-img"><img src="/elito/images/testimonial/img-2.jpg" alt="" /></div>
<div class="testimonial-img"><img src="/elito/images/testimonial/img-3.jpg" alt="" /></div>
<div class="testimonial-img"><img src="/elito/images/testimonial/img-4.jpg" alt="" /></div>
<div class="testimonial-img"><img src="/elito/images/testimonial/img-5.jpg" alt="" /></div>
<div class="testimonial-img"><img src="/elito/images/testimonial/img-6.jpg" alt="" /></div>
</div>
<div class="side-img-1"><img src="/elito/images/testimonial/img-2.jpg" alt="" /></div>
<div class="side-img-2"><img src="/elito/images/testimonial/img-3.jpg" alt="" /></div>
<div class="side-img-3"><img src="/elito/images/testimonial/img-4.jpg" alt="" /></div>
<div class="side-img-4"><img src="/elito/images/testimonial/img-5.jpg" alt="" /></div>
<div class="side-img-5"><img src="/elito/images/testimonial/img-6.jpg" alt="" /></div>
<div class="border-s1">&nbsp;</div>
<div class="border-s2">&nbsp;</div>
<div class="border-s3">&nbsp;</div>
</div>
<div class="shape-t">&nbsp;</div>
</div>
</div>
<div class="col-lg-6 col-12">
<div class="wpo-testimonial-items">
<div class="slider-nav">
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Cathi Falcon, <span>Software Engineer</span></h3>
</div>
</div>
</div>
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Robert Johnson, <span>Software Developer</span></h3>
</div>
</div>
</div>
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Jenelia Orkid, <span>Web Designer</span></h3>
</div>
</div>
</div>
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Cathi Falcon, <span>Software Enginee</span></h3>
</div>
</div>
</div>
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Cathi Falcon, <span>Software Enginee</span></h3>
</div>
</div>
</div>
<div class="wpo-testimonial-item">
<div class="wpo-testimonial-text">
<h4>Many desktop publishing packages and editors now use as their.</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of page when looking at its layout point of using is that it has more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making look like readable English.</p>
<div class="wpo-testimonial-text-btm">
<h3>Cathi Falcon, <span>Software Enginee</span></h3>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="left-shape">&nbsp;</div>
<div class="right-shape"><img src="/elito/images/testimonial/shape.png" alt="" /></div>
</section>
<!--End wpo-testimonial-section--></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				
<div id="mod-custom117" class="mod-custom custom">
    <!-- start wpo-pricing-section -->
<section class="wpo-pricing-section section-padding">
<div class="container">
<div class="row">
<div class="row justify-content-center">
<div class="col-lg-5">
<div class="wpo-section-title">
<h2>Pricing Plan</h2>
<p>Must explain to you how all this mistaken idea pleasure born and give you a complete account.</p>
</div>
</div>
</div>
</div>
<div class="wpo-pricing-wrap">
<div class="row">
<div class="col col-lg-4 col-md-6 col-12">
<div class="wpo-pricing-item">
<div class="wpo-pricing-top">
<div class="pricing-thumb"><span>Basic</span></div>
<div class="wpo-pricing-text">
<h2>$120<span> / per month</span></h2>
<p>Determine the Best Pricing Strategy For Your Business.</p>
</div>
</div>
<div class="wpo-pricing-bottom">
<div class="wpo-pricing-bottom-text">
<ul>
<li>Softwere Development</li>
<li>Web Development</li>
<li>Digital Marketing</li>
<li>Graphic Design</li>
<li>24/Support</li>
</ul>
<a href="/elito/pricing.html">CHOOSE PLAN</a></div>
</div>
</div>
</div>
<div class="col col-lg-4 col-md-6 col-12">
<div class="wpo-pricing-item">
<div class="wpo-pricing-top">
<div class="pricing-thumb"><span>Premium</span></div>
<div class="wpo-pricing-text">
<h2>$210<span> / per month</span></h2>
<p>Determine the Best Pricing Strategy For Your Business.</p>
</div>
</div>
<div class="wpo-pricing-bottom">
<div class="wpo-pricing-bottom-text">
<ul>
<li>Softwere Development</li>
<li>Web Development</li>
<li>Digital Marketing</li>
<li>Graphic Design</li>
<li>24/Support</li>
</ul>
<a href="/elito/pricing.html">CHOOSE PLAN</a></div>
</div>
</div>
</div>
<div class="col col-lg-4 col-md-6 col-12">
<div class="wpo-pricing-item">
<div class="wpo-pricing-top">
<div class="pricing-thumb"><span>Advanced</span></div>
<div class="wpo-pricing-text">
<h2>$373<span> / per month</span></h2>
<p>Determine the Best Pricing Strategy For Your Business.</p>
</div>
</div>
<div class="wpo-pricing-bottom">
<div class="wpo-pricing-bottom-text">
<ul>
<li>Softwere Development</li>
<li>Web Development</li>
<li>Digital Marketing</li>
<li>Graphic Design</li>
<li>24/Support</li>
</ul>
<a href="/elito/pricing.html">CHOOSE PLAN</a></div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- end container -->
<div class="shape-p">&nbsp;</div>
</section>
<!-- end wpo-pricing-section --></div>
	</div>
</div>
<div class="main-top bt-card ">
		<div class="bt-card-body">
				<section class="wpo-blog-section section-padding">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-5">
				<div class="wpo-section-title">
					<h2>Latest News</h2>
					<p></p>
				</div>
			</div>
		</div> 
			 
	<div class="wpo-blog-wrap wpo-blog-slide owl-carousel">
					<div class="wpo-blog-item">
	<div class="wpo-blog-img">
		<img src="https://demo-joomla.chipblue.net/elito/images/blog/img-6.jpg" alt="Have evolved over the years sometimes accident.">
	</div>
	<div class="wpo-blog-text">
		<ul>
			<li>01-Dec-2022</li>
		</ul>
		<h2><a href="/elito/index.php/blog/have-evolved-over-the-years-sometimes-accident">Have evolved over the years sometimes accident.</a></h2>
		<a class="details" href="/elito/index.php/blog/have-evolved-over-the-years-sometimes-accident">Read More ...</a>
	</div> 
	  
	   
	 
	 
		 
	

	
	

	 

	
	

	</div> 
<div class="wpo-blog-item">
	<div class="wpo-blog-img">
		<img src="https://demo-joomla.chipblue.net/elito/images/blog/img-4.jpg#joomlaImage://local-images/blog/img-4.jpg?width=868&height=514" alt="The Internet tend to repeat predefined chunks.">
	</div>
	<div class="wpo-blog-text">
		<ul>
			<li>01-Dec-2022</li>
		</ul>
		<h2><a href="/elito/index.php/blog/the-internet-tend-to-repeat-predefined-chunks">The Internet tend to repeat predefined chunks.</a></h2>
		<a class="details" href="/elito/index.php/blog/the-internet-tend-to-repeat-predefined-chunks">Read More ...</a>
	</div> 
	  
	   
	 
	 
		 
	

	
	

	 

	
	

	</div> 
<div class="wpo-blog-item">
	<div class="wpo-blog-img">
		<img src="https://demo-joomla.chipblue.net/elito/images/blog/img-4.jpg#joomlaImage://local-images/blog/img-4.jpg?width=868&height=514" alt="The Internet tend to repeat predefined chunks. (2)">
	</div>
	<div class="wpo-blog-text">
		<ul>
			<li>01-Dec-2022</li>
		</ul>
		<h2><a href="/elito/index.php/blog/the-internet-tend-to-repeat-predefined-chunks-2">The Internet tend to repeat predefined chunks. (2)</a></h2>
		<a class="details" href="/elito/index.php/blog/the-internet-tend-to-repeat-predefined-chunks-2">Read More ...</a>
	</div> 
	  
	   
	 
	 
		 
	

	
	

	 

	
	

	</div> 
<div class="wpo-blog-item">
	<div class="wpo-blog-img">
		<img src="https://demo-joomla.chipblue.net/elito/images/blog/img-5.jpg" alt="The standard chunk of used since the interested.">
	</div>
	<div class="wpo-blog-text">
		<ul>
			<li>01-Dec-2022</li>
		</ul>
		<h2><a href="/elito/index.php/blog/the-standard-chunk-of-used-since-the-interested">The standard chunk of used since the interested.</a></h2>
		<a class="details" href="/elito/index.php/blog/the-standard-chunk-of-used-since-the-interested">Read More ...</a>
	</div> 
	  
	   
	 
	 
		 
	

	
	

	 

	
	

	</div> 
	 
	</div>
</div>
</div>
	</div>
</div>

		 
			<div id="system-message-container" aria-live="polite"></div>

			<main>
			<div class="blog-featured" itemscope itemtype="https://schema.org/Blog">
    
    
    
    
    
</div>

			</main>
						 
		 
		
	 
 
	<!-- start wpo-site-footer -->
	<footer class="wpo-site-footer">
		<div class="footer-top widget    ">
		<div class="footer-body">
				
<div id="mod-custom119" class="mod-custom custom">
    <div class="upper-contact-area">
<div class="container">
<div class="contact-grids">
<div class="row align-items-center">
<div class="col col-lg-6">
<h2>Send me a message and make something together.</h2>
</div>
<div class="col col-lg-6">
<div class="send-message-btn"><a href="#" class="theme-btn">Contact Us</a></div>
</div>
</div>
<div class="left-shape">&nbsp;</div>
</div>
</div>
</div></div>
	</div>
</div>

		
		<div class="upper-footer">
			<div class="container">
				<div class="row">
					<div class="col col-lg-4 col-md-6 col-12">
						<div class="footer1 widget     about-widget">
		<div class="footer-body">
				
<div id="mod-custom120" class="mod-custom custom">
    <div class="logo widget-title"><a href="#" class="site-logo"><img src="/elito/images/logo.png" alt="" />Elito.</a></div>
<p>Welcome and open yourself to your truest love this year with us! With the Release Process</p>
<div class="social-icons">
<ul>
<li><a href="#"><i class="ti-facebook"></i></a></li>
<li><a href="#"><i class="ti-twitter-alt"></i></a></li>
<li><a href="#"><i class="ti-linkedin"></i></a></li>
<li><a href="#"><i class="ti-pinterest"></i></a></li>
<li><a href="#"><i class="ti-vimeo-alt"></i></a></li>
</ul>
</div></div>
	</div>
</div>
 
					</div>
					<div class="col col-lg-2 col-md-6 col-12">
						<div class="footer2 widget    link-widget">
			<div class="widget-title"><h3 class=" ">Navigation</h3></div>
		<div class="footer-body">
				
<div id="mod-custom121" class="mod-custom custom">
    <ul>
<li><a href="#about">About us</a></li>
<li><a href="#">Contact us</a></li>
<li><a href="#video">Video Guide</a></li>
<li><a href="#">Recent Post</a></li>
</ul></div>
	</div>
</div>
 
						 
					</div>
					<div class="col col-lg-3 col-md-6 col-12">
						<div class="footer3 widget     link-widget service-link-widget">
			<div class="widget-title"><h3 class=" ">All Services</h3></div>
		<div class="footer-body">
				
<div id="mod-custom122" class="mod-custom custom">
    <ul>
<li><a href="#">Web Design</a></li>
<li><a href="#">Web Development</a></li>
<li><a href="#">Brand Identity</a></li>
<li><a href="#">Digital Marketing</a></li>
</ul></div>
	</div>
</div>
 
					</div>
					<div class="col col-lg-3 col-md-6 col-12">
						<div class="footer4 widget    widget social-widget">
			<div class="widget-title"><h3 class=" ">Social Media</h3></div>
		<div class="footer-body">
				
<div id="mod-custom126" class="mod-custom custom">
    <ul>
<li><a href="#"><i><img src="/elito/images/1.png" alt="" /></i> Facebook</a></li>
<li><a href="#"><i><img src="/elito/images/2.png" alt="" /></i> Twitter</a></li>
<li><a href="#"><i><img src="/elito/images/3.png" alt="" /></i> Instagram</a></li>
<li><a href="#"><i><img src="/elito/images/4.png" alt="" /></i> Youtube</a></li>
</ul></div>
	</div>
</div>
 
						 
					</div>
				</div>
			</div> <!-- end container -->
			<div class="shadow-shape">
				<svg width="1319" height="1567" viewBox="0 0 1319 1567" fill="none">
					<g filter="url(#filter0_f_39_3833)">
						<circle cx="803" cy="803" r="303" fill="#59C378" fill-opacity="0.5" />
					</g>
					<defs>
						<filter id="filter0_f_39_3833" x="0" y="0" width="1606" height="1606"
							filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
							<feFlood flood-opacity="0" result="BackgroundImageFix" />
							<feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
							<feGaussianBlur stdDeviation="250" result="effect1_foregroundBlur_39_3832" />
						</filter>
					</defs>
				</svg>
			</div>
		</div>
		<div class="lower-footer">
			<div class="container">
				<div class="row">
					<div class="separator"></div>
					<div class="footer-copyright widget    ">
		<div class="footer-body">
				
<div id="mod-custom123" class="mod-custom custom">
    <p class="copyright">Copyright © Elito. All rights reserved.</p></div>
	</div>
</div>
 
					
				</div>
			</div>
		</div>
	</footer>
	<!-- end wpo-site-footer -->
</div>
<!-- end of page-wrapper -->
	<script src="https://demo-joomla.chipblue.net/elito/templates/elito/assets/js/bootstrap.bundle.min.js"></script> 
    <!-- Plugins for this template --> 
    <script src="https://demo-joomla.chipblue.net/elito/templates/elito/assets/js/jquery.dlmenu.js"></script>
    <script src="https://demo-joomla.chipblue.net/elito/templates/elito/assets/js/jquery-plugin-collection.js"></script>
    <!-- Moving Animation -->
    <script src="https://demo-joomla.chipblue.net/elito/templates/elito/assets/js/moving-animation.js"></script>
    <!-- Custom script for this template -->
    <script src="https://demo-joomla.chipblue.net/elito/templates/elito/assets/js/script.js"></script>    
	
</body>
</html>
